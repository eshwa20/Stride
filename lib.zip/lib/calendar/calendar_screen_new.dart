import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../controllers/xp_controller.dart';
import '../controllers/task_controller.dart';

class AnalyticsReportPage extends StatelessWidget {
  const AnalyticsReportPage({super.key});

  // Dark Theme Colors from your video
  static const Color backgroundColor = Color(0xFF0A120D);
  static const Color cardColor = Color(0xFF16251C);
  static const Color accentGreen = Color(0xFF2ECC71);

  @override
  Widget build(BuildContext context) {
    // 1. Check your TaskController: if the variable is named differently, update 'streakCount' below
    final taskProvider = Provider.of<TaskController>(context);
    final int streakValue = taskProvider.streakCount;
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Report", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            // 1. Summary Header
            _buildSummaryHeader(streakValue),
            const SizedBox(height: 25),
            
            // 2. Time Range Toggle
            _buildTimeToggle(),
            const SizedBox(height: 20),

            // 3. Weekly Bar Chart Card
            _buildSectionCard(
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Study Activity", style: TextStyle(color: Colors.white70, fontSize: 14)),
                  const SizedBox(height: 20),
                  SizedBox(height: 180, child: _buildBarChart()),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 4. Day Streak Card
            _buildSectionCard(
              _buildStreakRow(streakValue),
            ),
            const SizedBox(height: 25),
            
            const Align(
              alignment: Alignment.centerLeft,
              child: Text("Earned Badges", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 15),
            _buildBadgeGrid(),
            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }

  // Helper method for the summary
  Widget _buildSummaryHeader(int streak) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.local_fire_department, color: Colors.orange, size: 24),
                const SizedBox(width: 8),
                Text("$streak Days", style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
            const Text("Current Streak", style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
        const Text("Dec 2025", style: TextStyle(color: Colors.grey)),
      ],
    );
  }

  // Fix: Removed the named parameter 'child' to match how it's called in build
  Widget _buildSectionCard(Widget content) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: content,
    );
  }

  Widget _buildTimeToggle() {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(15)),
      child: Row(
        children: ["Day", "Week", "Month", "Year"].map((label) {
          bool isSelected = label == "Week";
          return Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: isSelected ? Colors.white.withOpacity(0.1) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(label, style: TextStyle(color: isSelected ? Colors.white : Colors.grey, fontSize: 13)),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildBarChart() {
    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: 10,
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (v, m) {
                const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
                if (v.toInt() >= days.length) return const SizedBox();
                return Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(days[v.toInt()], style: const TextStyle(color: Colors.grey, fontSize: 12)),
                );
              },
            ),
          ),
        ),
        barGroups: List.generate(7, (i) => _barGroup(i, [5.0, 8.0, 4.0, 9.0, 6.0, 3.0, 7.0][i], isToday: i == 3)),
      ),
    );
  }

  BarChartGroupData _barGroup(int x, double y, {bool isToday = false}) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          toY: y,
          color: isToday ? accentGreen : Colors.white.withOpacity(0.1),
          width: 18,
          borderRadius: BorderRadius.circular(4),
        )
      ],
    );
  }

  Widget _buildStreakRow(int currentStreak) {
    return Column(
      children: [
        Row(
          children: const [
            Icon(Icons.calendar_month, color: Colors.white70, size: 18),
            SizedBox(width: 10),
            Text("Day Streak", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(7, (index) {
            bool isDone = index <= 3; // Mocking visual for now
            return Column(
              children: [
                Text(["M", "T", "W", "T", "F", "S", "S"][index], style: const TextStyle(color: Colors.grey, fontSize: 10)),
                const SizedBox(height: 8),
                CircleAvatar(
                  radius: 14,
                  backgroundColor: isDone ? accentGreen : Colors.white10,
                  child: isDone ? const Icon(Icons.check, size: 16, color: Colors.black) : null,
                ),
              ],
            );
          }),
        ),
      ],
    );
  }

  Widget _buildBadgeGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4, mainAxisSpacing: 15, crossAxisSpacing: 15,
      ),
      itemCount: 4,
      itemBuilder: (context, index) => Container(
        height: 60,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.03),
          border: Border.all(color: Colors.white10),
        ),
        child: const Icon(Icons.lock_outline, color: Colors.white24, size: 20),
      ),
    );
  }
}