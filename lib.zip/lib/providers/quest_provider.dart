import 'package:flutter/material.dart';

class Quest {
  final String title;
  final String subtitle;
  final int xp;
  bool isCompleted;
  final DateTime date;

  Quest({
    required this.title, 
    required this.subtitle, 
    required this.xp, 
    this.isCompleted = false, 
    required this.date
  });
}

class QuestProvider extends ChangeNotifier {
  final List<Quest> _quests = [];

  List<Quest> get quests => _quests;

  void addQuest(Map<String, dynamic> data) {
    _quests.add(Quest(
      title: data['title'],
      subtitle: data['subtitle'],
      xp: data['xp'],
      date: DateTime.now(),
    ));
    notifyListeners();
  }

  void toggleQuest(int index) {
    _quests[index].isCompleted = !_quests[index].isCompleted;
    notifyListeners();
  }

  // Calculation for the Bar Charts
  double getCompletionRate() {
    if (_quests.isEmpty) return 0.0;
    int completed = _quests.where((q) => q.isCompleted).length;
    return completed / _quests.length;
  }
}