import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class AnalyticsReportPage extends StatelessWidget {
  const AnalyticsReportPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Primary colors from your app's theme
    const backgroundColor = Color(0xFF0A120D);
    const cardColor = Color(0xFF16251C);
    const accentGreen = Color(0xFF2ECC71);

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: const Icon(Icons.arrow_back_ios, color: Colors.white),
        title: const Text("Steps", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        actions: [
          TextButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.add, color: accentGreen, size: 18),
            label: const Text("Add", style: TextStyle(color: accentGreen)),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            // 1. Top Summary Section
            _buildSummaryHeader(),
            const SizedBox(height: 20),

            // 2. Time Filter Toggle
            _buildTimeFilter(cardColor, accentGreen),
            const SizedBox(height: 20),

            // 3. Weekly Bar Chart Card
            _buildCardContainer(
              cardColor,
              height: 250,
              child: _buildProgressChart(accentGreen),
            ),
            const SizedBox(height: 20),

            // 4. Day Streak Card
            _buildCardContainer(
              cardColor,
              child: _buildStreakSection(accentGreen),
            ),
            const SizedBox(height: 20),

            // 5. Badges Section (Placeholder as requested)
            const Align(
              alignment: Alignment.centerLeft,
              child: Text("Earned Badges", 
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 10),
            _buildBadgePlaceholder(),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // --- UI Components ---

  Widget _buildSummaryHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            const Icon(Icons.timer_outlined, color: Colors.white70, size: 20),
            const SizedBox(width: 8),
            const Text("4000", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(width: 4),
            Text("Steps", style: TextStyle(color: Colors.grey[500], fontSize: 14)),
          ],
        ),
        Text("02 Jan 2024", style: TextStyle(color: Colors.grey[500], fontSize: 14)),
      ],
    );
  }

  Widget _buildTimeFilter(Color cardColor, Color accent) {
    return Container(
      decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(30)),
      padding: const EdgeInsets.all(4),
      child: Row(
        children: ["Day", "Week", "Month", "Year"].map((label) {
          bool isSelected = label == "Month";
          return Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? Colors.white.withOpacity(0.1) : Colors.transparent,
                borderRadius: BorderRadius.circular(25),
              ),
              child: Center(
                child: Text(label, style: TextStyle(color: isSelected ? Colors.white : Colors.grey)),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildProgressChart(Color accent) {
    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: 4500,
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (v, m) => Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'][v.toInt()], 
                  style: const TextStyle(color: Colors.grey, fontSize: 10)),
              ),
            ),
          ),
          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 30,
            getTitlesWidget: (v, m) => Text("${v.toInt() ~/ 1000}k", style: const TextStyle(color: Colors.grey, fontSize: 10)))),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        barGroups: List.generate(7, (i) => BarChartGroupData(
          x: i,
          barRods: [BarChartRodData(
            toY: [3800, 2200, 3400, 4300, 2500, 3300, 2100][i].toDouble(),
            color: i == 3 ? accent : Colors.white.withOpacity(0.1),
            width: 30,
            borderRadius: BorderRadius.circular(4),
          )],
        )),
      ),
    );
  }

  Widget _buildStreakSection(Color accent) {
    return Column(
      children: [
        Row(children: const [
          Icon(Icons.calendar_today, color: Colors.white, size: 18),
          SizedBox(width: 10),
          Text("Day Streak", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'].asMap().entries.map((e) {
            bool active = e.key <= 3;
            return Column(
              children: [
                Text(e.value, style: const TextStyle(color: Colors.grey, fontSize: 10)),
                const SizedBox(height: 8),
                CircleAvatar(
                  radius: 14,
                  backgroundColor: active ? accent : Colors.white10,
                  child: active ? const Icon(Icons.check, size: 16, color: Colors.white) : null,
                ),
              ],
            );
          }).toList(),
        ),
        const SizedBox(height: 20),
        const Text("Amazing streak! keep going everyday champ", 
          style: TextStyle(color: Colors.grey, fontSize: 12)),
      ],
    );
  }

  Widget _buildBadgePlaceholder() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(4, (index) => Container(
        height: 60, width: 60,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white10, width: 2),
        ),
        child: const Icon(Icons.lock_outline, color: Colors.white24),
      )),
    );
  }

  Widget _buildCardContainer(Color color, {required Widget child, double? height}) {
    return Container(
      height: height,
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
      child: child,
    );
  }
}