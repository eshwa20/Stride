import 'package:flutter/material.dart';
import 'package:barcode_widget/barcode_widget.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ProfilePage(),
  ));
}

// --- DATA MODEL ---
class Coupon {
  final String brandName;
  final String logoUrl;
  final String category;
  final String discount;
  final int pointsRequired;
  final Color color;
  final String code;

  Coupon({
    required this.brandName,
    required this.logoUrl,
    required this.category,
    required this.discount,
    required this.pointsRequired,
    required this.color,
    required this.code,
  });
}

// --- PROFILE PAGE ---
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF9F3),
      appBar: AppBar(
        title: Text("STRIDE PROFILE", style: GoogleFonts.lexendExa(fontSize: 14)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(
              radius: 50,
              backgroundColor: Color(0xFFFFD8BE),
              child: Icon(Icons.person, size: 50, color: Colors.brown),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFD8BE),
                foregroundColor: Colors.brown,
                padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const RedeemPage())),
              icon: const Icon(Icons.confirmation_num_outlined),
              label: Text("REDEEM COUPONS", style: GoogleFonts.lexend(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}

// --- REDEEM PAGE ---
class RedeemPage extends StatelessWidget {
  const RedeemPage({super.key});

  final int userPoints = 1850; // Mock points earned from Daily Quests

  List<Coupon> get coupons => [
    Coupon(
      brandName: "Etle Fashion",
      logoUrl: "https://cdn-icons-png.flaticon.com/512/3050/3050231.png",
      category: "Clothing",
      discount: "30% OFF",
      pointsRequired: 500,
      color: const Color(0xFFF0E6EF),
      code: "STRIDE-ETLE",
    ),
    Coupon(
      brandName: "Kanshika Selfcare",
      logoUrl: "https://cdn-icons-png.flaticon.com/512/3520/3520119.png",
      category: "Skincare",
      discount: "FREE SERUM",
      pointsRequired: 800,
      color: const Color(0xFFEAF4F4),
      code: "STRIDE-GLOW",
    ),
    Coupon(
      brandName: "Veda Attire",
      logoUrl: "https://cdn-icons-png.flaticon.com/512/2950/2950151.png",
      category: "Clothing",
      discount: "₹1000 OFF",
      pointsRequired: 1200,
      color: const Color(0xFFFFF1E6),
      code: "STRIDE-VEDA",
    ),
    Coupon(
      brandName: "Loom & Leaf",
      logoUrl: "https://cdn-icons-png.flaticon.com/512/3050/3050220.png",
      category: "Home Decor",
      discount: "15% OFF",
      pointsRequired: 400,
      color: const Color(0xFFE2F0CB),
      code: "STRIDE-LOOM",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF9F3),
      appBar: AppBar(
        title: Text("REWARDS STORE", style: GoogleFonts.lexendExa(fontSize: 14)),
        backgroundColor: Colors.transparent,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: const Color(0xFFFFD8BE)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Your Stride Points:", style: GoogleFonts.lexend(color: Colors.grey[700])),
                  Text("$userPoints Pts", style: GoogleFonts.lexend(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.brown)),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: coupons.length,
              itemBuilder: (context, index) {
                final coupon = coupons[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 15),
                  child: GestureDetector(
                    onTap: () => _showEnlarged(context, coupon),
                    child: ClipPath(
                      clipper: TicketClipper(),
                      child: Container(
                        height: 110,
                        color: coupon.color,
                        child: Row(
                          children: [
                            const SizedBox(width: 20),
                            CircleAvatar(backgroundColor: Colors.white70, child: Image.network(coupon.logoUrl, height: 25)),
                            const SizedBox(width: 15),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(coupon.brandName, style: GoogleFonts.lexend(fontWeight: FontWeight.bold, fontSize: 16)),
                                  Text(coupon.category, style: GoogleFonts.lexend(fontSize: 11, color: Colors.black54)),
                                ],
                              ),
                            ),
                            const VerticalDivider(indent: 20, endIndent: 20, thickness: 1, color: Colors.black12),
                            SizedBox(
                              width: 100,
                              child: Center(child: Text(coupon.discount, textAlign: TextAlign.center, style: GoogleFonts.lexend(fontWeight: FontWeight.w900, fontSize: 13))),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showEnlarged(BuildContext context, Coupon coupon) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            Container(width: 50, height: 5, decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(10))),
            const SizedBox(height: 30),
            Image.network(coupon.logoUrl, height: 60),
            const SizedBox(height: 10),
            Text(coupon.brandName.toUpperCase(), style: GoogleFonts.lexendExa(letterSpacing: 3, fontSize: 12)),
            const SizedBox(height: 30),
            ClipPath(
              clipper: TicketClipper(),
              child: Container(
                padding: const EdgeInsets.all(30),
                color: coupon.color,
                child: Column(
                  children: [
                    Text(coupon.discount, style: GoogleFonts.lexend(fontSize: 40, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 20),
                    BarcodeWidget(
                      barcode: Barcode.code128(),
                      data: coupon.code,
                      height: 70,
                      width: double.infinity,
                      drawText: false,
                    ),
                    const SizedBox(height: 10),
                    Text(coupon.code, style: GoogleFonts.shareTechMono(letterSpacing: 2, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Text("Expires in 48 hours", style: GoogleFonts.lexend(color: Colors.redAccent, fontSize: 12)),
            const SizedBox(height: 15),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[700],
                minimumSize: const Size(double.infinity, 60),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              onPressed: userPoints >= coupon.pointsRequired ? () => Navigator.pop(context) : null,
              child: Text(
                userPoints >= coupon.pointsRequired ? "REDEEM FOR ${coupon.pointsRequired} PTS" : "INSUFFICIENT POINTS",
                style: GoogleFonts.lexend(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- TICKET SHAPE CLIPPER ---
class TicketClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    double r = 15;
    path.lineTo(0, size.height / 2 - r);
    path.arcToPoint(Offset(0, size.height / 2 + r), radius: Radius.circular(r), clockwise: true);
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, size.height / 2 + r);
    path.arcToPoint(Offset(size.width, size.height / 2 - r), radius: Radius.circular(r), clockwise: true);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> old) => false;
}