// lib/home/analysis/analysis_page.dart
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import 'package:stride/providers/quest_provider.dart';

class AnalysisPage extends StatelessWidget {
  const AnalysisPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: const Color(0xFF161621), // Matching your theme
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text("PERFORMANCE", style: TextStyle(letterSpacing: 2, fontSize: 16, fontWeight: FontWeight.bold)),
          bottom: const TabBar(
            indicatorColor: Color(0xFF6C63FF),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white38,
            tabs: [Tab(text: "DAY"), Tab(text: "WEEK"), Tab(text: "MONTH"), Tab(text: "YEAR")],
          ),
        ),
        body: TabBarView(
          children: [
            _buildAnalysisView(context, "Daily"),
            _buildAnalysisView(context, "Weekly"),
            _buildAnalysisView(context, "Monthly"),
            _buildAnalysisView(context, "Yearly"),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalysisView(BuildContext context, String title) {
    final provider = Provider.of<QuestProvider>(context);
    final completion = provider.getCompletionRate();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("$title Progress", style: const TextStyle(color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 20),
          
          // BAR CHART
          AspectRatio(
            aspectRatio: 1.7,
            child: BarChart(
              BarChartData(
                maxY: 1.0,
                barGroups: _getBarGroups(completion),
                titlesData: FlTitlesData(show: false),
                gridData: FlGridData(show: false),
                borderData: FlBorderData(show: false),
              ),
            ),
          ),

          const SizedBox(height: 40),
          _buildStatTile("Quests Completed", "${provider.quests.where((q) => q.isCompleted).length}", Icons.check_circle_outline),
          _buildStatTile("Average Accuracy", "${(completion * 100).toInt()}%", Icons.speed),
          _buildStatTile("XP Gained", "${provider.quests.where((q) => q.isCompleted).fold(0, (sum, item) => sum + item.xp)} XP", Icons.bolt),
        ],
      ),
    );
  }

  List<BarChartGroupData> _getBarGroups(double rate) {
    return List.generate(7, (index) => BarChartGroupData(
      x: index,
      barRods: [
        BarChartRodData(
          toY: index == 6 ? rate : 0.4 + (index * 0.05), // Fake history + real today
          color: index == 6 ? const Color(0xFF6C63FF) : Colors.white10,
          width: 22,
          borderRadius: BorderRadius.circular(6),
        )
      ],
    ));
  }

  Widget _buildStatTile(String label, String value, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF1E1E2C), borderRadius: BorderRadius.circular(16)),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF00D2D3)),
          const SizedBox(width: 16),
          Text(label, style: const TextStyle(color: Colors.white60)),
          const Spacer(),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        ],
      ),
    );
  }
}