// lib/providers/quest_provider.dart
import 'package:flutter/material.dart';

class Quest {
  final String title;
  final String subtitle;
  final int xp;
  bool isCompleted;
  final DateTime createdAt;

  Quest({
    required this.title,
    required this.subtitle,
    required this.xp,
    this.isCompleted = false,
    required this.createdAt,
  });
}

class QuestProvider extends ChangeNotifier {
  final List<Quest> _quests = [];

  List<Quest> get quests => _quests;

  void addQuest(Map<String, dynamic> data) {
    _quests.add(Quest(
      title: data['title'],
      subtitle: data['subtitle'],
      xp: data['xp'],
      isCompleted: false,
      createdAt: DateTime.now(),
    ));
    notifyListeners();
  }

  void toggleQuest(int index) {
    _quests[index].isCompleted = !_quests[index].isCompleted;
    notifyListeners();
  }

  // Logic for Analysis Charts
  double getCompletionRate(String period) {
    if (_quests.isEmpty) return 0.0;
    
    // In a real app, you would filter _quests by period (Day/Week/Month)
    // For this demo, we calculate based on current completion
    int completed = _quests.where((q) => q.isCompleted).length;
    return (completed / _quests.length);
  }
}